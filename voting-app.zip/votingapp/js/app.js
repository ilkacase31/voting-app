
let winner = false;
const cards = document.querySelector('.cards');
cards.innerHTML = getCards();
const cardButtons = document.querySelectorAll('.card-btn');

const trumpVotesEl = document.querySelector('.votes-number-solteco');

const bidenVotesEl = document.querySelector('.votes-number-mooge');

cardButtons.forEach(cardButton => {
    cardButton.addEventListener('click', (e) => {
        if (e.target.classList.contains('btn-solteco')) {
            addVote(0, 'solteco', trumpVotesEl)
        } else {
            addVote(1, 'mooge', bidenVotesEl)
        }
    })
})