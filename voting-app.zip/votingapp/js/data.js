const candidates = [
    {
        id: "solteco",
        name: "Abdirahman Solteco",
        party: "Kulmiye Party",
        votes: 260,
    },
    {
        id: "mooge",
        name: "Updikarim Moge",
        party: "Wadani Party",
        votes: 260,
    }
]